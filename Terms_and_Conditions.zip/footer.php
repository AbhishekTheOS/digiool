
            <footer class="main-footer">
    <div class="circle-layer"></div>
    <div class="pattern-layer-one" style="background-image: url('images/background/pattern-12.png')"></div>
    <div class="pattern-layer-two" style="background-image: url('images/background/pattern-13.png')"></div>
    <div class="pattern-layer-three" style="background-image: url('images/background/pattern-14.png')"></div>
    <div class="pattern-layer-four" style="background-image: url('images/background/pattern-13.png')"></div>
    <div class="auto-container">

        <div class="widgets-section">
            <div class="row">
                <div class="col-sm-4"></div>
                <div class="col-sm-4">
                    <center>
                        <a href="index.html">
                            <img style="width:200px" src="images/logo_digiool.png" alt="Digiool Logo | Footer">
                        </a>
                    </center>
                </div>
                <div class="col-sm-4"></div> 
            </div>
            <br>  

            <div class="row clearfix"> 
                <div class="footer-column col-lg-3 col-md-12 col-sm-12">
                    <div class="footer-widget logo-widget">
                        <h5>Help Desk</h5> 
                        <ul class="info-list">
                            <li><i class="fa fa-mobile" aria-hidden="true"></i> <a href="tel:+91-9341528591"> +91-9341528591</a></li>
                            <li><i class="fa fa-mobile" aria-hidden="true"></i> <a href="tel:+91-9341528592"> +91-9341528592</a></li>
                            <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <a href="#"> <span class="__cf_email__" data-cfemail="">helpdesk@digiool.com</span></a></li>
                        </ul> 
                        <ul class="social-box">
                            <li class="facebook"><a target="_blank" href="https://www.facebook.com/DigioolAnOnlineSchool" class="fa fa-facebook-f"></a></li>
                            <li class="pinterest"><a target="_blank" href="https://www.youtube.com/channel/UC7jVF0D-LjPESaK4bFoUaow" class="fa fa-youtube"></a></li>
                            <li class="twitter"><a target="_blank" href="http://twitter.com/" class="fa fa-twitter"></a></li>
                            <li class="pinterest"><a target="_blank" href="http://pinterest.com/" class="fa fa-pinterest-p"></a></li>
                        </ul> 
						
						 <h5 style="margin-bottom: 0px;">LEARNER APP</h5>
                            <a><img style="width:180px" src="images/ios_andriod.png" alt="Digiool IOS & Andriood" title="Digiool IOS & Andriood"></a>
                            <h5 style="margin-top: 0px; margin-bottom: 0px;">Educator APP</h5>
                            <a><img style="width:180px" src="images/ios_andriod.png" alt="Digiool IOS & Andriood" title="Digiool IOS & Andriood"></a>
                    </div>
                </div>


                <div class="footer-column col-lg-9 col-md-12 col-sm-12">
                    <div class="row clearfix"> 
                        <div class="column col-lg-4 col-md-4 col-sm-12">
                            <h5>About Digiool</h5>
                            <ul class="list">
                                <li><a href="about.php">About us</a></li>
                                <li><a href="Careers.php">Careers</a></li>
                                
                                <li><a href="Privacy_Policy.php">Privacy Policy</a></li>
                                <li><a href="Terms_and_Conditions.php">Terms and Conditions</a></li> 
								 <li><a href="#">Sitemap</a></li>
                                 <li><a href="#">FAQs</a></li>								 
                            </ul>
							
							 <h5>RESOURCES</h5>
                            <ul class="list">
                                <li><a href="about.php">Blog</a></li>
                                <li><a href="Careers.php">Video</a></li>
                                <li><a href="#">All Products</a></li>
                                <li><a href="Privacy_Policy.php">Digiool Results</a></li>
                                <li><a href="Terms_and_Conditions.php">Sign Up</a></li> 
								
                            </ul>
							
							
							
							
							
							
							
                        </div> 
                        <div class="column col-lg-4 col-md- col-sm-12">
                            <h5> Exam Preparation</h5>
                            <ul class="list">
                                <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">Free CAT Prep</a></li>
                                <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">Free IAS Prep</a></li>
                                <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">Maths</a></li>
                                <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">Physics</a></li>
                                <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">Chemistry</a></li>
								<li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">Biology</a></li>
                            </ul>
							
							
							 <h5> Popular Courses</h5>
                            <ul class="list">
                                <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">JEE</a></li>
                                <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">NEET</a></li>
                                <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">UGC NET</a></li>
                                <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">CBSE Classes Upto XII</a></li>
                                <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">Chemistry</a></li>
								<li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">CLAT</a></li>
                            </ul>
							
							
							
							
							
							
							
							
							
							
                        </div> 
                        <div class="column col-lg-4 col-md-4 col-sm-12">
                            <h5>Free Textbook Solution</h5>
                            <ul class="list">
                                <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">NCERT Solutions</a></li>
                                <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">NCERT Exemplar</a></li>
                                <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">RD Sharma Solutions</a></li>
                                <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">RS Aggarwal Solutions</a></li>
                                <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">ICSE Selina Solutions</a></li> 
								 <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" target="_blank">NCERT Solutions for Class 6 to 12</a></li> 
                            </ul>
							
							
							
							
							 <h5>Other Links</h5>
                            <ul class="list">
                                <li><a href="#" target="_blank">User Guidelines</a></li>
                                <li><a href="#" target="_blank">Site Map</a></li>
                                <li><a href="#" target="_blank">Refund Policy</a></li>
                                <li><a href="#" target="_blank">Legal Notices</a></li>
                               
								 
                            </ul>
							
							
							
							
							
							
							
							
                        </div> 
                       
                    </div>
                </div> 
            </div>
        </div>  
    </div>
    <br>
</footer> 

<div id="footers" style=" left: 0px; bottom: 0px; width: 100%; background: #000000d9; z-index: 1; text-align: right;">
    © <a href="http://digiool.com/" target="_blank" style="color:white;"> Digiool Education Private Limited</a>  
</div>
</div>


<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>

<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/appear.js"></script>
<script src="js/parallax.min.js"></script>
<script src="js/tilt.jquery.min.js"></script>
<script src="js/jquery.paroller.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/nav-tool.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/script.js"></script> 
</body> 


</html>