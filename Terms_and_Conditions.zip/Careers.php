<?php include 'header_menu.php';?>

          


  <!-- Page Title Section -->
            <section class="page-title-section">
                <div class="icon-layer-one" style="background-image: url('images/icons/icon-5.png')"></div>
                <div class="icon-layer-two" style="background-image: url('images/icons/icon-6.png')"></div>
                <div class="icon-layer-three" style="background-image: url('images/icons/icon-4.png')"></div>
                <div class="icon-layer-four" style="background-image: url('images/icons/icon-7.png')"></div>
                <div class="icon-layer-five" style="background-image: url('images/icons/icon-7.png')"></div>
                <div class="icon-layer-six" style="background-image: url('images/icons/icon-8.png')"></div>
                <div class="auto-container"> 

                    <ul class="page-breadcrumb">
                        <li><a href="index.html">Home</a></li>
                        <li>Careers</li>
                    </ul>
                    <div class="content-box">
                        <h2>Careers</h2>
						
                    </div>
                </div>
            </section>
            <!-- End Page Title Section -->









<!-- Contact Page Section -->
    <section class="contact-page-section">
		<div class="pattern-layer-three" style="background-image: url(images/icons/icon-8.png)"></div>
		<div class="auto-container">
			<div class="row clearfix">
				
			
				<!-- Form Column -->
				<div class="form-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="circle-layer"></div>
						<div class="pattern-layer-one" style="background-image: url(images/icons/icon-7.png)"></div>
						<div class="pattern-layer-two" style="background-image: url(images/icons/icon-9.png)"></div>
						<h2>Apply This Form</h2>
						<br>
						
						<!-- Contact Form -->
						<div class="contact-form">
							<form method="post" action="sendemail.php" id="contact-form">
								
								<div class="form-group">
									<input type="text" name="username" placeholder="Name" required="">
								</div>
								
								<div class="form-group">
									<input type="email" name="email" placeholder="Email" required="">
								</div>
								
								
								
								<div class="form-group">
									<input type="text" name="phone" placeholder="Phone" required="">
								</div>
								
								<div class="form-group">
									<input type="text" name="Current Address" placeholder="Current Address" required="">
								</div>
								
								<div class="form-group">
									<select id="Applying for Position" name="Applying for Position" class="form-group">
      <option value="1">General Manager Sales/Marketing manager</option>
      <option value="2">Project Manager</option>
      <option value="3">Sales Engineer</option>
      <option value="4">Installation Engineer</option>
      <option value="5">Project Engineer</option>
      <option value="6">Senior Accountant</option>
      <option value="7">Junior Accountant</option>
      <option value="8">Sales Executive</option>
      <option value="9">Site Engineer</option>
      <option value="10">Site Supervisor</option>
      <option value="11">Draftsman</option>
      <option value="12">Technician</option>
      <option value="13">Semi Skilled Technician</option>
      <option value="14">Trainees</option>
    </select>
								</div>
								
								
								<div class="form-group">
									<textarea class="" name="Address" placeholder="Address"></textarea>
								</div>
								
								<div class="form-group">
								<label class="col-md-6 control-label" for="UploadResume">Upload Resume</label>
									 <input id="UploadResume" name="UploadResume" class="input-file" type="file">
								</div>
								
								
								
								
								
								
								
								
								
								
								
								<div class="form-group">
									<button class="theme-btn btn-style-five" type="submit" name="submit-form">Apply Now</button>
								</div>
								
							</form>
						</div>
							
					</div>
						
					</div>
					
						<!-- Info Column -->
				<div class="info-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<img src="images/job.jpg">
					</div>
				</div>
				
				</div>
				
			</div>
		</div>
	</section>
	<!-- End Contact Page Section -->


		  





<?php include 'footer.php';?>