
<!DOCTYPE html>
<html> 
<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1" />
<head>
        <meta charset="utf-8">
<title>Digiool | A Digital School</title> 
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100;300;400;500;700;900&amp;display=swap" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<meta content="Digiool | A Digital School" name="author">
<meta name="keywords" content="online courses,learn english online,online learning,learn anything online,best way to learn finnish online,learn finnish online course,online course,learn to drive online course,online,learn to drive online course - everything a learner driver needs!,learn english,how i learn things online,how to learn things online,learn python online,learn python,hunar online courses,learn graphic design online,online courses in fashion designing,english courses online,digiool,Jharkhand Online Video Class,Jharkhand Video Class,TheOS Live Class,digiool.digioll,digi wool,digool,digi ool,online education platforms in india,top online education platforms in world,online learning platforms for business,online learning platforms examples,best free online learning platforms,online learning platforms for schools,online learning platforms free,online learning platforms for kids,online learning platforms examples, online live class platform, best online course platforms 2020, list of online learning platforms, how to create an online course for free, online learning platforms india, hosting courses online, online learning platforms free">
<meta content="Digiool, A Pioneer edtech based in Ranchi, is an online learning platform where Students can learn from KG to PG at their own Pace. Stay Safe, Stay at Home while Learning with World Class Faculties. Digiool brings Education at your Door Place." name="description">

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">

<script async src="https://www.googletagmanager.com/gtag/js?id=G-DTHX0D0TGR"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-DTHX0D0TGR');
</script>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
    var Tawk_API = Tawk_API || {}, Tawk_LoadStart = new Date();
    (function () {
        var s1 = document.createElement("script"), s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/6116678fd6e7610a49b00a21/1fcvo92fc';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
</script>




        <script>
            function replace_url() {
                window.history.pushState({}, document.title, "/" + "digiool");
                window.history.replaceState({}, document.title, "/" + "digiool");
            }
        </script>










<!--End of Tawk.to Script-->
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">  
        <style> 
            .form2 {position:relative;}
            .form2 input{
                width:100% ;
                border:1px solid #d9d9d9;
                padding:10px 15px;
                border-radius:200px;
                box-shadow:none
            }
            .form2 .button-Serch{
                right:0;
                top:1px;
                position: absolute;
                background:#00ACED;
                color:#fff !important;
                padding:10px 25px;
                border-radius:200px;
                transition:all ease-in-out 0.5s;
                cursor:pointer;
            }
            .form2 .button-Serch:hover
            {
                background:#333;
            } 
            .card {
                background-color: #ffffff;
                border: 1px solid rgba(0, 34, 51, 0.1);
                box-shadow: 2px 4px 10px 0 rgba(0, 34, 51, 0.05), 2px 4px 10px 0 rgba(0, 34, 51, 0.05);
                border-radius: 0.15rem;
            }
            .tab-card {
                border:1px solid #eee;
            } 
            .tab-card-header {
                background:none;
            } 
            .tab-card-header > .nav-tabs {
                border: none;
                margin: 0px;
            }
            .tab-card-header > .nav-tabs > li {
                margin-right: 2px;
            }
            .tab-card-header > .nav-tabs > li > a {
                border: 0;
                border-bottom:2px solid transparent;
                margin-right: 0;
                color: #737373;
                padding: 2px 15px;
            } 
            .tab-card-header > .nav-tabs > li > a.show {
                border-bottom:2px solid #007bff;
                color: #007bff;
            }
            .tab-card-header > .nav-tabs > li > a:hover {
                color: #007bff;
            } 
            .tab-card-header > .tab-content {
                padding-bottom: 0;
            } 
            .inner-box:before
            {
                display: none;
                border: 0px solid #06092d;
            }
            .service-block .inner-box .border-layer
            {
                border: 0px solid #06092d; 
            }
            .team-block .inner-box .lower-content .designation{
                text-align: center !important;
                color: #380101;
                margin-bottom: -10px;
            }
        </style> 
    </head>
    <body class="hidden-bar-wrapper"> 
        <div class="page-wrapper">

            




<style>
    .page-links-box a {
        position: relative;
        border-radius: 5px;
        font-size: 15px;
        color: #06092d;
        line-height: 32px;
        text-align: left;
        margin: 0px 9px 20px;
        display: inline-block;
        background-color: #fbeff7;
        padding: 15px 35px 15px 20px;
    }
</style>
<header class="main-header"> 
    <div class="header-upper">
        <div class="outer-container clearfix">

            <div class="pull-left logo-box">
                <div class="logo"><a href="index.php"><img style="width:180px" src="images/logo_digiool.png" alt="Digiool Logo" title="Digiool Logo | Online Learning Video Class"></a></div>
            </div>

            <div class="nav-outer clearfix"> 
                <div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>

                <nav class="main-menu navbar-expand-md">
                    <div class="navbar-header"> 	
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>

                    <div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
                        <ul class="navigation clearfix">
                            <li class="dropdown has-mega-menu"><a href="##"><span style="color: green; font-weight: 700;">Live Classes <i class="fa fa-arrow-down"></i></span></a>
                                <div class="mega-menu">
                                    <div class="upper-box">
                                        <div class="page-links-box">
                                            
                                            <a href="http://www.digiool.com/digiool/StudentSignUp.jsp" class="link"><span class="icon flaticon-bar-chart"></span>JEE Zeal Batch 2023</a>
                                                
                                            <a href="http://www.digiool.com/digiool/StudentSignUp.jsp" class="link"><span class="icon flaticon-bar-chart"></span>JEE Target Batch 2022</a>
                                                
                                            <a href="http://www.digiool.com/digiool/StudentSignUp.jsp" class="link"><span class="icon flaticon-bar-chart"></span>NEET Zeal Batch 2023</a>
                                                
                                            <a href="http://www.digiool.com/digiool/StudentSignUp.jsp"><span class="icon flaticon-bar-chart"></span>NEET Target Batch 2022</a>
                                                
                                        </div>
                                    </div> 
                                    <div class="lower-box">
                                        <h3>Book Your Demo Class Now</h3>
                                        <div class="text">Before making your mind, Give Yourself a Trial. <span style="color: #efa200; font-weight: 700;">Go For Demo Class.</span></div>
                                        <div class="btn-box">
                                            <a href="#" target="_blank" class="theme-btn btn-style-five">Register Now </a>
                                        </div>
                                        <div class="side-icon">
                                            <img src="images/resource/mega-menu-icon.png" alt="Digiool">
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li ><a href="/index.php"><span data-hover="Home">Home</span></a>

                            </li>
                            <li class="dropdown"><a href="about.php">About</a>
                                <ul>
                                    <li><a href="about.php">About Digiool</a></li> 
                                    <li><a href="teacher.php">Team</a></li> 

                                </ul>
                            </li>  
                            <li class=""><a href="faq.php" >FAQs</a></li> 
                            <li><a href="http://www.digiool.com/digiool/StudentSignUp.jsp">Sign Up</a></li> 
                        </ul>
                    </div>
                </nav>


                <div class="outer-box clearfix"> 
                    <ul class="social-box"> 
                        <li class="facebook"><a target="_blank" href="https://www.facebook.com/DigioolAnOnlineSchool" class="fa fa-facebook-f"></a></li>
                        <li class="twitter"><a target="_blank" href="https://www.youtube.com/channel/UC7jVF0D-LjPESaK4bFoUaow" class="fa fa-youtube"></a></li>
                        <li class="instagram"><a target="_blank" href="http://instagram.com/" class="fa fa-instagram"></a></li>
                    </ul> 
                </div> 
            </div> 
        </div>
    </div>

    <div class="sticky-header">
        <div class="auto-container clearfix"> 
            <div class="logo pull-left">
                <a href="index.php" title=""><img style="width:200px" src="images/logo.png" alt="Digiool Logo" title="Digiool Logo"></a>
            </div> 
            <div class="pull-right"> 
                <nav class="main-menu"></nav> 
                <div class="outer-box clearfix"></div> 
            </div>
        </div>
    </div>

    <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <div class="close-btn"><span class="icon flaticon-multiply"></span></div> 
        <nav class="menu-box">
            <div class="nav-logo"><a href="index.php"><img src="images/logo.png" alt="Digiool Logo" title="Digiool Logo"></a></div>
            <div class="menu-outer"></div>
        </nav>
    </div> 

</header>

