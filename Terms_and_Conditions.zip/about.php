<?php include 'header_menu.php';?>

          

            <section class="banner-section-three">
                <div class="pattern-layer-two" style="background-image: url('images/background/pattern-21.png')"></div>
                <div class="auto-container"> 
                    <ul class="page-breadcrumb">
                        <li><a href="index.html">Home</a></li>
                        <li>Introduction</li>
                    </ul>

                    <div class="row clearfix">

                        <div class="content-column col-lg-9 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <div class="pattern-layer-one" style="background-image: url('images/main-slider/pattern-1.png')"></div>
                                <div class="icon-layer" style="background-image: url('images/icons/icon-2.png')"></div>
                                <div class="icon-layer-two" style="background-image: url('images/icons/icon-5.png')"></div>
                                <h2>Moulding creators of the future</h2><br>
								  <div class="text">Digiool started with a dream to inspire school kids to fall in love with coding. Our vision is to empower every child with the knowledge of coding, so that they can build anything they imagine.</div>
                            </div>
                        </div> 

                        <div class="image-column col-lg-3 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <div class="icon-layer-three" style="background-image: url('images/icons/icon-3.png')"></div>
                                <div class="icon-layer-four" style="background-image: url('images/icons/icon-2.png')"></div>
                                <div class="icon-layer-five" style="background-image: url('images/icons/icon-4.png')"></div>
                                <div class="image">
                                    <img src="images/page-title-1.png" alt="Digiool | Online Video Learning Class">
                                </div>
                                <div class="image-two">
                                    <img src="images/page-title-2.png" alt="Digiool | Online Video Learning Class">
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

<br>

<!-- Career Section -->
	<section class="career-section" style="background-color: #FFF7F5;">
		<div class="auto-container">
			<!-- Sec Title -->
			<br><br><br>
			<center><div class="sec-title">
				<h2>Our Beliefs</h2>
			</div></center>
			
			<div class="row ">
			
			
			<div class="image-column  col-sm-6 border-right" >
			<div class="row"	<!-- Image Column -->
				<div class="image-column col-lg-5 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="image titlt" data-tilt data-tilt-max="4">
							<img src="images/empowering-children.webp" alt="" />
						</div>
					</div>
				</div>
				
				<!-- Content Column -->
				<div class="content-column col-lg-7 col-md-12 col-sm-12">
					<div class="inner-column">
						<h5>Empowering Children</h5>
						<div class="text">
							<p>The future is digital and we believe providing children with the knowledge of coding will safeguard their future.</p>
						</div>
						
					</div>
				</div>
				</div>
				
				












				
				
			</div>
			
			
		<div class="image-column  col-sm-6">
			<div class="row"	<!-- Image Column -->
				<div class="image-column col-lg-5 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="image titlt" data-tilt data-tilt-max="4">
							<img src="images/inquisitiveness.webp" alt="" />
						</div>
					</div>
				</div>
				
				<!-- Content Column -->
				<div class="content-column col-lg-7 col-md-12 col-sm-12">
					<div class="inner-column">
						<h5>Nurturing inquisitiveness</h5>
						<div class="text">
							<p>We encourage children to ask as many questions as possible. We believe a curious mind will do wonders.</p>
						</div>
						
					</div>
				</div>
				</div>
			
			
		





			
		
			</div>
				
			
			

<div class="image-column  col-sm-6 border-right border-top">
			<div class="row"	<!-- Image Column -->
				<div class="image-column col-lg-5 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="image titlt" data-tilt data-tilt-max="4">
							<img src="images/childhood-wonder.webp" alt="" />
						</div>
					</div>
				</div>
				
				<!-- Content Column -->
				<div class="content-column col-lg-7 col-md-12 col-sm-12">
					<div class="inner-column">
						<h5>The wonder of childhood</h5>
						<div class="text">
							<p>We believe that childhood is a wonderful age where valuable thoughts are shaped and through our curriculum we try to inculcate learnings through a fun way.</p>
						</div>
						
					</div>
				</div>
				</div>



</div>

<div class="image-column  col-sm-6 border-top">
			<div class="row"	<!-- Image Column -->
				<div class="image-column col-lg-5 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="image titlt" data-tilt data-tilt-max="4">
							<img src="images/coding.webp" alt="" />
						</div>
					</div>
				</div>
				
				<!-- Content Column -->
				<div class="content-column col-lg-7 col-md-12 col-sm-12">
					<div class="inner-column">
						<h5>Coding should be fun</h5>
						<div class="text">
							<p>We want to make learning computer science a fun activity children look forward to. We are constantly working to mke our sessions and activities as interactive and entertaining for the kids as possible.</p>
						</div>
						
					</div>
				</div>
				</div>



		
	</section>
	<!-- End Career Section -->









<!-- Career Section -->
	<section class="career-section" style="background-color: #3a004b;">
		<div class="auto-container">
			<!-- Sec Title -->
			<br><br><br><br>
			<center><div class="sec-title">
				<h2 style="color:#fff;">Do you think you share our vision?</h2>
				<br>
				<p style="color:#fff; font-size:18px;" >We would love to hear from you</p>
				
				
				<div class="btn-box">
							<a href="#" class="theme-btn btn-style-four"><span class="txt">Join our team</span></a>
						</div>
				
				
				
				
				
			</div></center>
			
			</div>

		
	</section>
	<!-- End Career Section -->






















		  





<?php include 'footer.php';?>