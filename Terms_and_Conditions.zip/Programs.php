
<!DOCTYPE html>
<html> 
<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1" />
<head>
        <meta charset="utf-8">
<title>Digiool | A Digital School</title> 
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100;300;400;500;700;900&amp;display=swap" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<meta content="Digiool | A Digital School" name="author">
<meta name="keywords" content="online courses,learn english online,online learning,learn anything online,best way to learn finnish online,learn finnish online course,online course,learn to drive online course,online,learn to drive online course - everything a learner driver needs!,learn english,how i learn things online,how to learn things online,learn python online,learn python,hunar online courses,learn graphic design online,online courses in fashion designing,english courses online,digiool,Jharkhand Online Video Class,Jharkhand Video Class,TheOS Live Class,digiool.digioll,digi wool,digool,digi ool,online education platforms in india,top online education platforms in world,online learning platforms for business,online learning platforms examples,best free online learning platforms,online learning platforms for schools,online learning platforms free,online learning platforms for kids,online learning platforms examples, online live class platform, best online course platforms 2020, list of online learning platforms, how to create an online course for free, online learning platforms india, hosting courses online, online learning platforms free">
<meta content="Digiool, A Pioneer edtech based in Ranchi, is an online learning platform where Students can learn from KG to PG at their own Pace. Stay Safe, Stay at Home while Learning with World Class Faculties. Digiool brings Education at your Door Place." name="description">

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">

<script async src="https://www.googletagmanager.com/gtag/js?id=G-DTHX0D0TGR"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-DTHX0D0TGR');
</script>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
    var Tawk_API = Tawk_API || {}, Tawk_LoadStart = new Date();
    (function () {
        var s1 = document.createElement("script"), s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/6116678fd6e7610a49b00a21/1fcvo92fc';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
</script>




        <script>
            function replace_url() {
                window.history.pushState({}, document.title, "/" + "digiool");
                window.history.replaceState({}, document.title, "/" + "digiool");
            }
        </script>










<!--End of Tawk.to Script-->
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">  
      
    </head>
    <body class="hidden-bar-wrapper"> 
        <div class="page-wrapper">

            





<header class="main-header"> 
    <div class="header-upper">
        <div class="outer-container clearfix">

          <center>  <div class="logo-box">
                <div class="logo"><a href="index.php"><img style="width:180px" src="images/logo_digiool.png" alt="Digiool Logo" title="Digiool Logo | Online Learning Video Class"></a></div>
            </div>
 </center>
           
        </div>
    </div>

  

  

</header>





<style>
.form-sec{width:400px; background:#ccc; padding:15px;width: 400px;
    background: #f8f9fa;padding: 15px;box-shadow: 0 0 4px #ccc;}


	


</style>



			
		
			
			
			
		<!-- Contact Page Section -->
    <section class="contact-page-section" style="margin-top:-50px;">
		<div class="pattern-layer-three" style="background-image: url(images/icons/icon-8.png)"></div>
		<div class="auto-container">
			<div class="row clearfix">
				
				
				<!-- Form Column -->
				<div class="form-column col-lg-6 col-md-12 col-sm-12">
					<div class="">
						
						
						<h2>Book your Free Class</h2>
						<div class="text">Learn from India's best teachers</div>
						
						<!-- Contact Form -->
						<div class="contact-form">
							<form method="post" action="sendemail.php" id="contact-form">
								
								<div class="form-group">
									<input type="text" name="username" placeholder="Name" required="">
								</div>
								
								<div class="form-group">
									<input type="email" name="email" placeholder="Email" required="">
								</div>
								
								<div class="form-group">
									<input type="text" name="phone" placeholder="Phone" required="">
								</div>
								
								<div class="form-group">
									<textarea class="" style="height: 100px;" name="message" placeholder="For Query"></textarea>
								</div>
								
								 <div class="form-group">
                            <div class="g-recaptcha" data-sitekey="6LfKURIUAAAAAO50vlwWZkyK_G2ywqE52NU7YO0S" data-callback="verifyRecaptchaCallback" data-expired-callback="expiredRecaptchaCallback"></div>
                            <input class="form-control d-none" data-recaptcha="true" required data-error="Please complete the Captcha">
                            <div class="help-block with-errors"></div>
                        </div>
								
								
								<div class="form-group">
									<button class="btn btn-primary btn-ultra-voilet" type="submit" name="submit-form">Submit</button>
								</div>
								
							</form>
						</div>
							
					</div>
						
					</div>
					
					
					
					<!-- Info Column -->
				<div class="info-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						
						<center><h2> How it works</h2></center>
						 <div class="container">
        <div class="row mb-2">
            <div class="col-md-12">
              <a href="#" class="text-dark">
              <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-xs-1 col-sm-2 col-md-1 mr-3" >
						<div  style="background-color:#690372; height:50px; width:50px; border-radius:50%; padding-top:5px; font-size:22px; font-weight:bold; color:#fff;">
                      <center> <p>1</p></center>
					   </div>
                        </div>
                        <div class="col-xs-8 col-sm-7 col-md-9">
                      
                        <p>After registering, you can select and confirm a time slot for your free class as per your convenience</p>
                        </div>
                    </div>
                </div>
              </div>
              </a>
            </div>
        </div>
       
         <div class="row mb-2">
            <div class="col-md-12">
              <a href="#" class="text-dark">
              <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-xs-1 col-sm-2 col-md-1 mr-3" >
						<div  style="background-color:#030b72; height:50px; width:50px; border-radius:50%; padding-top:5px; font-size:22px; font-weight:bold; color:#fff;">
                      <center> <p>2</p></center>
					   </div>
                        </div>
                        <div class="col-xs-8 col-sm-7 col-md-9">
                      
                        <p>Every class will be for 60 minutes</p>
                        </div>
                    </div>
                </div>
              </div>
              </a>
            </div>
        </div>
      
      
	  
	  
	   <div class="row mb-2">
            <div class="col-md-12">
              <a href="#" class="text-dark">
              <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-xs-1 col-sm-2 col-md-1 mr-3" >
						<div  style="background-color:#647203; height:50px; width:50px; border-radius:50%; padding-top:5px; font-size:22px; font-weight:bold; color:#fff;">
                      <center> <p>3</p></center>
					   </div>
                        </div>
                        <div class="col-xs-8 col-sm-7 col-md-9">
                      
                        <p>Join the class on time and learn from our top teachers</p>
                        </div>
                    </div>
                </div>
              </div>
              </a>
            </div>
        </div>
	  
	  
	  
	   <div class="row mb-2">
            <div class="col-md-12">
              <a href="#" class="text-dark">
              <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-xs-1 col-sm-2 col-md-1 mr-3" >
						<div  style="background-color:#722203; height:50px; width:50px; border-radius:50%; padding-top:5px; font-size:22px; font-weight:bold; color:#fff;">
                      <center> <p>4</p></center>
					   </div>
                        </div>
                        <div class="col-xs-8 col-sm-7 col-md-9">
                      
                        <p>Get all your doubts clarified instantly during the class</p>
                        </div>
                    </div>
                </div>
              </div>
              </a>
            </div>
        </div>
	  
	  
	   <div class="row mb-2">
            <div class="col-md-12">
              <a href="#" class="text-dark">
              <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-xs-1 col-sm-2 col-md-1 mr-3" >
						<div  style="background-color:#723f03; height:50px; width:50px; border-radius:50%; padding-top:5px; font-size:22px; font-weight:bold; color:#fff;">
                      <center> <p>5</p></center>
					   </div>
                        </div>
                        <div class="col-xs-8 col-sm-7 col-md-9">
                      
                        <p>Revise your concepts after class through the homework that will be provided</p>
                        </div>
                    </div>
                </div>
              </div>
              </a>
            </div>
        </div>
	  
	  
       
      
      
    </div>
						
					</div>
				</div>
				
					
					
					
					
					
					
					
					
					
					
					
					
					
					
				</div>
				
			</div>
		</div>
	</section>
	<!-- End Contact Page Section -->	
			
			
			
			 <script src='https://www.google.com/recaptcha/api.js'></script>
			
			
	

<div id="footers" style=" position: fixed; left: 0px; bottom: 0px; width: 100%; background: #000000d9; z-index: 1; text-align: right;">
    © <a href="http://digiool.com/" target="_blank" style="color:white;"> Digiool Education Private Limited</a>  
</div>
</div>


<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>

<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/appear.js"></script>
<script src="js/parallax.min.js"></script>
<script src="js/tilt.jquery.min.js"></script>
<script src="js/jquery.paroller.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/nav-tool.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/script.js"></script> 
</body> 


</html>