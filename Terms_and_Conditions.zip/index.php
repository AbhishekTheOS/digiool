<?php include 'header_menu.php';?>

<style>
.form-sec{width:400px; background:#ccc; padding:15px;width: 400px;
    background: #f8f9fa;padding: 15px;box-shadow: 0 0 4px #ccc;}


	


</style>




            <section class="banner-section" style="background-image: url('images/digiool_bg.png'); background-repeat: no-repeat;background-size: 100%;" >
                <div class="container"> 

                    <div class="row clearfix"> 
                        <div class="content-column col-lg-6 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <div class="row">
                                    <div class="col-8">
                                        <div class="card tab-card" style="margin-top:-60px;">  
                                           
<div class="form-sec">
 <center> <h4 style="color:#000;">Book your Free Class</h4>
  <p>Learn from India's best teacher</p></center>
  
 
  <table width="100%" >
  <td><hr /></td>
  <td style="width:1px; padding: 0 5px; white-space: nowrap; color:#000;">Enter Your Details</td>
  <td><hr /></td>
</table>
  
  
 <form name="qryform" id="qryform"  method="post" action="#" onsubmit="return(validate());" novalidate="novalidate">
    <div class="form-group">
      <label>Name:</label>
      <input type="text" class="form-control"   placeholder="Enter Your Child Name" name="name">
    </div>
    <div class="form-group">
      <label>Email:</label>
      <input type="email" class="form-control" id="name" placeholder="Enter Email" name="email">
    </div>
    
    <div class="form-group">
      <label>Phone No.:</label>
      <input type="text" class="form-control" id="bt" onclick="toggle(this)"  placeholder="Enter Phone no." name="phone">
    </div>
	
	 <div class="form-group" id="bt" onclick="toggle(this)" >
      <label>States</label>
     
	  
	  <select class="form-control"    name="" >
  <option  value="#"  >Select States</option>
  <option value="#" >Andhra Pradesh</option>
  <option value="#">Arunachal Pradesh</option>
  <option value="#">Assam</option>
   <option value="#">Bihar</option>
  <option value="#">Chhattisgarh</option>
   <option value="#">Goa</option>
  <option value="#">Gujarat</option>
   <option value="#">Haryana</option>
  <option value="#">Himachal Pradesh</option>
  <option value="#">Jharkhand</option>
  <option value="#">Karnataka</option>
   <option value="#">Kerala</option>
  <option value="#">Madhya Pradesh</option>
   <option value="#">Maharashtra</option>
  <option value="#">Manipur</option>
   <option value="#">Meghalaya</option>
  <option value="#">Mizoram</option>
  
  <option value="#">Odisha</option>
  <option value="#">Punjab</option>
   <option value="#">Rajasthan</option>
  <option value="#">Others</option>
  
  
</select>
	  
	  
    </div>
	
	
								 <div class="form-group"  id="cont" style="display:none">
                            <div class="g-recaptcha" data-sitekey="6LfKURIUAAAAAO50vlwWZkyK_G2ywqE52NU7YO0S" data-callback="verifyRecaptchaCallback" data-expired-callback="expiredRecaptchaCallback"></div>
                            <input class="form-control d-none" data-recaptcha="true" required data-error="Please complete the Captcha">
                            <div class="help-block with-errors"></div>
                        </div>
    
   <center> <button type="submit" class="btn btn-default" style="background: linear-gradient(to right, #f7b733, #fc4a1a); color:#fff;">Schedule a Free Class</button></center>
  </form>
  </div>

                                        </div>
                                    </div>
                                    <br><br>
                                </div> 
                            </div>
                        </div> 
                        <div class="image-column col-lg-6 col-md-12 col-sm-12"></div> 
                    </div>

                </div>
            </section>
			
			<script>
    function toggle(ele) {
        var cont = document.getElementById('cont');
        if (cont.style.display == 'block') {
            cont.style.display = 'none';

            document.getElementById(ele.id).value = '';
        }
        else {
            cont.style.display = 'block';
            document.getElementById(ele.id).value = '';
        }
    }
</script>
		


            <!---<section class="instructor-section">
                <div class="background-layer" style="background-image:url('images/background/1.png')"></div>
                <div class="background-layer-one" style="background-image:url('images/background/pattern-1.png')"></div>
                <div class="background-layer-two" style="background-image:url('images/background/pattern-2.png')"></div>

                <div class="auto-container">
                    <div class="row clearfix">

                        <div class="blocks-column col-lg-8 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <div class="row clearfix"> 
                                    <div class="service-block col-lg-6 col-md-6 col-sm-12">
                                        <div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                                            <div class="border-layer"></div>
                                            <div class="">
                                                <div class="">
                                                    <img src="images/teacher_digiool.gif" alt="Digiool Logo" title="Digiool Logo | Online Learning Video Class">
                                                </div>
                                            </div>
                                            <h4><a>Trusted Faculties</a></h4>
                                            <div class="text">Avg. 8+ Years of Experience with leading Institutions of Ranchi. Taught more than 1.0 million students on average 8 Years of Experience. </div>
                                        </div>
                                    </div> 
                                    <div class="service-block col-lg-6 col-md-6 col-sm-12">
                                        <div class="inner-box wow fadeInLeft" data-wow-delay="150ms" data-wow-duration="1500ms">
                                            <div class="border-layer"></div>
                                            <div class="">
                                                <div class="">
                                                    <img style="width: 115px;" src="images/24-7.png" alt="Digiool Logo" title="Digiool Logo | Online Learning Video Class">
                                                </div>
                                            </div>
                                            <h4><a>Flexible Timing</a></h4>
                                            <div class="text">Learn at Your Pace with our Recorded Classroom Program. Every Sunday is Doubt Session Day. Evening Batches. Alternate Days.</div>
                                        </div>
                                    </div> 
                                </div>
                            </div>
                        </div>


                        <div class="instructor-column col-lg-4 col-md-12 col-sm-12">
                            <div class="inner-column wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <h4>About Digiool</h4>
                                <p>Digiool, A Pioneer edtech based in Ranchi, is an online learning platform where Students can learn from KG to PG at their own Pace. Stay Safe, Stay at Home while Learning with World Class Faculties. Digiool brings Education at your Door Place. </p>
                                <a class="click-here" href="about.php">Know More</a> 
                            </div>
                        </div>

                    </div>
                </div> 
            </section> --->



<style>
.bfc-learning-prg-card {
    display: flex;
    justify-content: space-evenly;
    align-items: center;
    position: relative;
	
}


.btn-ultra-voilet {
  background: #fc4a1a;  /* fallback for old browsers */
    background: -webkit-linear-gradient(to right, #f7b733, #fc4a1a);  /* Chrome 10-25, Safari 5.1-6 */
    background: linear-gradient(to right, #f7b733, #fc4a1a); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
    color: #fff;
    border: 1px solid #f2f2f2;
}

</style>


			  
			  
			  
			  
			  <div class="auto-container" style="padding: 0px 0px 0px;  margin-top:-270px;">
                    <div class="sec-title centered">
                        <h2 style="color:#000; font-family:calibri;">Comprehensive Learning Programs<br> & Classes for all Students</h2>
                     <p style="color:#000; font-size:18px;">Become lifelong learners with India's best teachers,<br>
engaging video lessons and personalised learning journeys</p>

						    
                    </div> 
			  
			   </div> 
			  
			  
			  

         <!--- section--->  <section class="skill-section" >
             
			 
			
			    
			 
			 
			 
               <div class="container shadow  rounded" style="background-color:#f2f2f2;" >
			   
			   
			     <center>
                                <p style="padding-top:5px;">
                                    <span style="padding: 5px 20px; background-image: linear-gradient(to right, #5c72ff, #8c3fff); font-weight: bold; border-radius: 0 0 10px 10px;text-align: center; font-size: 16px; color: white;">JEE/NEET</span>
                                </p>
                               
                                     </center>
			   
			   
			   <div class="row">
			   
			                        
			   
			   
			   
			   
			   
			   
			   <div class="col-sm-6">
			    <div class="row border-right" style=" padding:10px 40px 10px;" >
				 <div class="bfc-learning-prg-card">
			     <div class="col-sm-6"><img src="images/JEE.png" style="max-width: 190px;" class="align-items-center"></div>
			     <div class="col-sm-6">
				 <img src="images/logo.png" style="width:150px;">
				 <p style="color:#000; font-size:14px;">Personalised learning app<br>
to learn anytime, anywhere</p> 
<a href="Programs/index.php">Know more ></p>


				 </div>
			   </div>
			   </div>
			   </div>
			   
			   
			   
			   
			   
			   
			   
			   
			   
			    <div class="col-sm-6">
				 <div class="row" style=" padding:10px 60px 10px;">
				 <div class="bfc-learning-prg-card left">
			     <div class="col-sm-6 "><img src="images/classes-tutor-img.png" style="max-width: 190px;" class="pull-left"></div>
			     <div class="col-sm-6">
				<img src="images/logo.png" style="width:150px;">
				 <p style="color:#000; font-size:14px;">Personalised learning app<br>
to learn anytime, anywhere</p> 
<a href="Programs/index.php">Know more ></p>


				 </div>
			   </div>
			   </div>
				
				
				
				</div>
			   
			   </div>
			   
			   <center><a href="Programs/index.php" target="_blank" class="btn btn-primary btn-ultra-voilet" style="margin-top:-20px; z-index:999999999; position:relative;">Book a FREE class</a> </center> 
			   
			   
			   
			   
			      <br>
			   </div>
            </section>


 <!--- section--->







         <!--- section--->  <section class="skill-section" >
             
               <div class="container shadow  rounded" style="background-color:#f2f2f2;" >
			   
			   
			     <center>
                                <p style="padding-top:5px;">
                                    <span style="padding: 5px 20px; background-image: linear-gradient(to right, #5c72ff, #8c3fff); font-weight: bold; border-radius: 0 0 10px 10px;text-align: center; font-size: 16px; color: white;">Classes 9 - 12</span>
                                </p>
                               
                                     </center>
			   
			   
			   <div class="row">
			   
			                        
			   
			   
			   
			   
			   
			   
			   <div class="col-sm-6">
			    <div class="row border-right" style=" padding:10px 40px 10px;" >
				 <div class="bfc-learning-prg-card">
			     <div class="col-sm-6"><img src="images/btla.png" style="max-width: 190px;" class="align-items-center"></div>
			     <div class="col-sm-6">
				 <img src="images/logo.png" style="width:150px;">
				 <p style="color:#000; font-size:14px;">Personalised learning app<br>
to learn anytime, anywhere</p> 
<a href="">Know more ></p>


				 </div>
			   </div>
			   </div>
			   </div>
			   
			   
			   
			   
			   
			   
			   
			   
			   
			    <div class="col-sm-6">
				 <div class="row" style=" padding:10px 60px 10px;">
				 <div class="bfc-learning-prg-card left">
			     <div class="col-sm-6 "><img src="images/nine.png" style="max-width: 190px;" class="pull-left"></div>
			     <div class="col-sm-6">
				<img src="images/logo.png" style="width:150px;">
				 <p style="color:#000; font-size:14px;">Personalised learning app<br>
to learn anytime, anywhere</p> 
<a href="">Know more ></p>


				 </div>
			   </div>
			   </div>
				
				
				
				</div>
			   
			   </div>
			   
			   <center><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" class="btn btn-primary btn-ultra-voilet" style="margin-top:-20px; z-index:999999999; position:relative;">Book a FREE class</a> </center> 
			   
			   
			   
			   
			      <br>
			   </div>
            </section>


 <!--- section--->








         <!--- section--->  <section class="skill-section" >
             
               <div class="container shadow  rounded" style="background-color:#f2f2f2;" >
			   
			   
			     <center>
                                <p style="padding-top:5px;">
                                    <span style="padding: 5px 20px; background-image: linear-gradient(to right, #5c72ff, #8c3fff); font-weight: bold; border-radius: 0 0 10px 10px;text-align: center; font-size: 16px; color: white;">Classes 6 - 8</span>
                                </p>
                               
                                     </center>
			   
			   
			   <div class="row">
			   
			                        
			   
			   
			   
			   
			   
			   
			   <div class="col-sm-6">
			    <div class="row border-right" style=" padding:10px 40px 10px;" >
				 <div class="bfc-learning-prg-card">
			     <div class="col-sm-6"><img src="images/six8.png" style="max-width: 190px;" class="align-items-center"></div>
			     <div class="col-sm-6">
				 <img src="images/logo.png" style="width:150px;">
				 <p style="color:#000; font-size:14px;">Personalised learning app<br>
to learn anytime, anywhere</p> 
<a href="">Know more ></p>


				 </div>
			   </div>
			   </div>
			   </div>
			   
			   
			   
			   
			   
			   
			   
			   
			   
			    <div class="col-sm-6">
				 <div class="row" style=" padding:10px 60px 10px;">
				 <div class="bfc-learning-prg-card left">
			     <div class="col-sm-6 "><img src="images/sixto8.png" style="max-width: 190px;" class="pull-left"></div>
			     <div class="col-sm-6">
				<img src="images/logo.png" style="width:150px;">
				 <p style="color:#000; font-size:14px;">Personalised learning app<br>
to learn anytime, anywhere</p> 
<a href="">Know more ></p>


				 </div>
			   </div>
			   </div>
				
				
				
				</div>
			   
			   </div>
			   
			   <center><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" class="btn btn-primary btn-ultra-voilet" style="margin-top:-20px; z-index:999999999; position:relative;">Book a FREE class</a> </center> 
			   
			   
			   
			   
			      <br>
			   </div>
            </section>


 <!--- section--->










         <!--- section--->  <section class="skill-section" >
             
               <div class="container shadow  rounded" style="background-color:#f2f2f2;" >
			   
			   
			     <center>
                                <p style="padding-top:5px;">
                                    <span style="padding: 5px 20px; background-image: linear-gradient(to right, #5c72ff, #8c3fff); font-weight: bold; border-radius: 0 0 10px 10px;text-align: center; font-size: 16px; color: white;">Classes 1 - 5</span>
                                </p>
                               
                                     </center>
			   
			   
			   <div class="row">
			   
			                        
			   
			   
			   
			   
			   
			   
			   <div class="col-sm-6">
			    <div class="row border-right" style=" padding:10px 40px 10px;" >
				 <div class="bfc-learning-prg-card">
			     <div class="col-sm-6"><img src="images/onetofive.png" style="max-width: 190px;" class="align-items-center"></div>
			     <div class="col-sm-6">
				 <img src="images/logo.png" style="width:150px;">
				 <p style="color:#000; font-size:14px;">Personalised learning app<br>
to learn anytime, anywhere</p> 
<a href="">Know more ></p>


				 </div>
			   </div>
			   </div>
			   </div>
			   
			   
			   
			   
			   
			   
			   
			   
			   
			    <div class="col-sm-6">
				 <div class="row" style=" padding:10px 60px 10px;">
				 <div class="bfc-learning-prg-card left">
			     <div class="col-sm-6 "><img src="images/one2five.png" style="max-width: 190px;" class="pull-left"></div>
			     <div class="col-sm-6">
				<img src="images/logo.png" style="width:150px;">
				 <p style="color:#000; font-size:14px;">Personalised learning app<br>
to learn anytime, anywhere</p> 
<a href="">Know more ></p>


				 </div>
			   </div>
			   </div>
				
				
				
				</div>
			   
			   </div>
			   
			   <center><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" class="btn btn-primary btn-ultra-voilet" style="margin-top:-20px; z-index:999999999; position:relative;">Book a FREE class</a> </center> 
			   
			   
			   
			   
			      <br>
			   </div>
            </section>


 <!--- section--->







         <!--- section--->  <section class="skill-section" >
             
               <div class="container shadow  rounded" style="background-color:#f2f2f2;" >
			   
			   
			     <center>
                                <p style="padding-top:5px;">
                                    <span style="padding: 5px 20px; background-image: linear-gradient(to right, #5c72ff, #8c3fff); font-weight: bold; border-radius: 0 0 10px 10px;text-align: center; font-size: 16px; color: white;">Pre Schooling/ Nursery</span>
                                </p>
                               
                                     </center>
			   
			   
			   <div class="row">
			   
			                        
			   
			   
			   
			   
			   
			   
			   <div class="col-sm-6">
			    <div class="row border-right" style=" padding:10px 40px 10px;" >
				 <div class="bfc-learning-prg-card">
			     <div class="col-sm-6"><img src="images/PreSchooling.png" style="max-width: 190px;" class="align-items-center"></div>
			     <div class="col-sm-6">
				 <img src="images/logo.png" style="width:150px;">
				 <p style="color:#000; font-size:14px;">Personalised learning app<br>
to learn anytime, anywhere</p> 
<a href="">Know more ></p>


				 </div>
			   </div>
			   </div>
			   </div>
			   
			   
			   
			   
			   
			   
			   
			   
			   
			    <div class="col-sm-6">
				 <div class="row" style=" padding:10px 60px 10px;">
				 <div class="bfc-learning-prg-card left">
			     <div class="col-sm-6 "><img src="images/Nursery.png" style="max-width: 190px;" class="pull-left"></div>
			     <div class="col-sm-6">
				<img src="images/logo.png" style="width:150px;">
				 <p style="color:#000; font-size:14px;">Personalised learning app<br>
to learn anytime, anywhere</p> 
<a href="">Know more ></p>


				 </div>
			   </div>
			   </div>
				
				
				
				</div>
			   
			   </div>
			   
			   <center><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" class="btn btn-primary btn-ultra-voilet" style="margin-top:-20px; z-index:999999999; position:relative;">Book a FREE class</a> </center> 
			   
			   
			   
			   
			      <br>
			   </div>
            </section>


 <!--- section--->








<br><br><br><br><br>








           
            <section class="courses-section" style=" background: -webkit-linear-gradient(to right, #000, #000); 
    background: linear-gradient(to right, #000, #000);">
                
                <div class="auto-container" style="padding: 50px 0px 0px; ">
                    <div class="sec-title centered">
					
					
					
					
					
                        <h2 style="color:#fff;">Unlock your Success Possibilities from Your Own town</h2>
                       
						<div class="sign">
      <h4 style="color:#ffe00c;">Be Gully Boys !</h4>
    </div>
	
						  <center><a href="http://www.digiool.com/digiool/StudentSignUp.jsp" class="btn btn-primary btn-ultra-voilet" style="position:relative; margin-top:40px;">Join Digiool Now</a> </center> 
						
                      
                        <br> 
                    </div> 
                </div>
            </section> 


            <section class="team-section-two">
                <div class="auto-container">
                
                    <div class="inner-container">
                      
                        <div class="color-layer"></div> 
                        <div class="row clearfix"> 
                            <div class="skill-column col-lg-12 col-md-12 col-sm-12">
                                <div class="inner-column"> 
                                    <div class="sec-title"> 
                                        <div class="text" style="text-align: center; font-size: 36px; font-weight: 700;margin-top: -90px;">Our Instructors</div>
                                        <div class="text" style="text-align: center; font-size: 14px; margin-top: -4px; font-style: italic;">Teachers as a Team</div>
                                    </div>  
                                </div>
                            </div>  
                        </div>

                        <div class="row clearfix"> 
                            <div class="team-block col-lg-3 col-md-6 col-sm-12">
                                <div class="inner-box">
                                    <div class="image">
                                        <img src="images/teacher/1.jpg" alt="Digiool | Rakesh Kumar, Physics">
                                    </div>
                                    <div class="lower-content">
                                        <h5><a><center>Mr. Rakesh Kumar</center></a></h5>
                                        <div class="designation">Physics Teacher</div>
                                        <div class="designation">10 Years + Exp.</div>
                                    </div>
                                </div>
                            </div> 
                            <div class="team-block col-lg-3 col-md-6 col-sm-12">
                                <div class="inner-box">
                                    <div class="image">
                                        <img src="images/teacher/2.jpg" alt="Digiool | R. K. Singh, Biology">
                                    </div>
                                    <div class="lower-content">
                                        <h5><a><center>Mr. R. K. Singh</center></a></h5> 
                                        <div class="designation">Biology Teacher</div>
                                        <div class="designation">6 Years + Exp.</div>
                                    </div>
                                </div>
                            </div>
                            <div class="team-block col-lg-3 col-md-6 col-sm-12">
                                <div class="inner-box">
                                    <div class="image">
                                        <img src="images/teacher/3.jpg" alt="Digiool | Vishal Gupta, Physics">
                                    </div>
                                    <div class="lower-content">
                                        <h5><a><center>Mr. Vishal Gupta</center></a></h5>  
                                        <div class="designation">Physics Teacher</div>
                                        <div class="designation">BIT Sindri, 6 Years + Exp.</div>
                                    </div>
                                </div>
                            </div>
                            <div class="team-block col-lg-3 col-md-6 col-sm-12">
                                <div class="inner-box">
                                    <div class="image">
                                        <img src="images/teacher/4.jpg" alt="Digiool | Hemant Sinha, Chemistry">
                                    </div>
                                    <div class="lower-content">
                                        <h5><a><center>Mr. Hemant Sinha</center></a></h5>  
                                        <div class="designation">Chemistry Teacher</div>
                                        <div class="designation">6 Years + Exp.</div>
                                    </div>
                                </div>
                            </div> 
                        </div>
                    </div>
                </div>
            </section>

           

           <!--- <section class="skill-section" style="margin-top: 0px;">
                <div class="pattern-layer" style="background-image:url('images/background/pattern-8.png')"></div>
                <div class="auto-container" style="margin-top: -80px;">
                    <div class="row clearfix"> 
                        <div class="skill-column col-lg-7 col-md-12 col-sm-12">
                            <div class="inner-column"> 
                                <div class="sec-title">
                                    <div class="title">Get the Digiool Advantage</div>
                                    <h2><br>What makes us special?</h2>
                                </div> 
                                <div class="skills"> 
                                    <div class="skill-item">
                                        <div class="skill-header clearfix">
                                            <div class="skill-title">Highly Qualified & Experienced Faculty</div>
                                            <div class="skill-percentage">
                                                <div class="count-box">
                                                    <span class="count-text" data-speed="2000" data-stop="90"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="skill-bar">
                                            <div class="bar-inner"><div class="bar progress-line" data-width="90"></div></div>
                                        </div>
                                    </div> 
                                    <div class="skill-item">
                                        <div class="skill-header clearfix">
                                            <div class="skill-title">Technology Based Learning Solutions </div>
                                            <div class="skill-percentage"><div class="count-box"><span class="count-text" data-speed="2000" data-stop="95"></span></div></div>
                                        </div>
                                        <div class="skill-bar">
                                            <div class="bar-inner"><div class="bar progress-line" data-width="95"></div></div>
                                        </div>
                                    </div>   
                                    <div class="skill-item">
                                        <div class="skill-header clearfix">
                                            <div class="skill-title">More Accessible & Personalized Practice & Testing</div>
                                            <div class="skill-percentage"><div class="count-box"><span class="count-text" data-speed="2000" data-stop="75"></span></div></div>
                                        </div>
                                        <div class="skill-bar">
                                            <div class="bar-inner"><div class="bar progress-line" data-width="75"></div></div>
                                        </div>
                                    </div> 
                                    <div class="skill-item">
                                        <div class="skill-header clearfix">
                                            <div class="skill-title">Visually rich content to enable conceptual clarity </div>
                                            <div class="skill-percentage"><div class="count-box"><span class="count-text" data-speed="2000" data-stop="75"></span></div></div>
                                        </div>
                                        <div class="skill-bar">
                                            <div class="bar-inner"><div class="bar progress-line" data-width="75"></div></div>
                                        </div>
                                    </div> 
                                    <div class="skill-item">
                                        <div class="skill-header clearfix">
                                            <div class="skill-title">Interactive & engaging video lessons</div>
                                            <div class="skill-percentage"><div class="count-box"><span class="count-text" data-speed="2000" data-stop="75"></span></div></div>
                                        </div>
                                        <div class="skill-bar">
                                            <div class="bar-inner"><div class="bar progress-line" data-width="75"></div></div>
                                        </div>
                                    </div> 
                                </div> 
                            </div>
                        </div> 
                        <div class="image-column col-lg-5 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <div class="circle-one"></div>
                                <div class="circle-two"></div>
                                <div class="image titlt" data-tilt data-tilt-max="4">
                                    <img src="images/resource/skill.png" alt="Digiool | Mr. Ankit Jaiswal">
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </section>---->

      
			
			
			
			<section class="skill-section" style="margin-top: 10px;">
             
                <div class="auto-container" >
                    <div class="row clearfix"> 
                        <div class="skill-column col-lg-7 col-md-12 col-sm-12">
                            <div class="inner-column"> 
                                <div class="sec-title">
                                    <div class="title">Get the Digiool Advantage</div>
                                    <h2>What makes us special?</h2>
                                </div> 
                                <div class="skills"> 
                                    <div class="skill-item">
                                        <div class="skill-header clearfix">
                                            <div class="skill-title">Highly Qualified & Experienced Faculty</div>
                                            <div class="skill-percentage">
                                                <div class="count-box">
                                                    <span class="count-text" data-speed="2000" data-stop="90"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="skill-bar">
                                            <div class="bar-inner"><div class="bar progress-line" data-width="90"></div></div>
                                        </div>
                                    </div> 
                                    <div class="skill-item">
                                        <div class="skill-header clearfix">
                                            <div class="skill-title">Technology Based Learning Solutions </div>
                                            <div class="skill-percentage"><div class="count-box"><span class="count-text" data-speed="2000" data-stop="95"></span></div></div>
                                        </div>
                                        <div class="skill-bar">
                                            <div class="bar-inner"><div class="bar progress-line" data-width="95"></div></div>
                                        </div>
                                    </div>   
                                    <div class="skill-item">
                                        <div class="skill-header clearfix">
                                            <div class="skill-title">More Accessible & Personalized Practice & Testing</div>
                                            <div class="skill-percentage"><div class="count-box"><span class="count-text" data-speed="2000" data-stop="75"></span></div></div>
                                        </div>
                                        <div class="skill-bar">
                                            <div class="bar-inner"><div class="bar progress-line" data-width="75"></div></div>
                                        </div>
                                    </div> 
                                    <div class="skill-item">
                                        <div class="skill-header clearfix">
                                            <div class="skill-title">Visually rich content to enable conceptual clarity </div>
                                            <div class="skill-percentage"><div class="count-box"><span class="count-text" data-speed="2000" data-stop="75"></span></div></div>
                                        </div>
                                        <div class="skill-bar">
                                            <div class="bar-inner"><div class="bar progress-line" data-width="75"></div></div>
                                        </div>
                                    </div> 
                                    <div class="skill-item">
                                        <div class="skill-header clearfix">
                                            <div class="skill-title">Interactive & engaging video lessons</div>
                                            <div class="skill-percentage"><div class="count-box"><span class="count-text" data-speed="2000" data-stop="75"></span></div></div>
                                        </div>
                                        <div class="skill-bar">
                                            <div class="bar-inner"><div class="bar progress-line" data-width="75"></div></div>
                                        </div>
                                    </div> 
                                </div> 
                            </div>
                        </div> 
                        <div class="image-column col-lg-5 col-md-12 col-sm-12">
					
						
						  <div class="sec-title">
                                    <div class="title">Digiool | A Digital School</div>
                                    <h2>Learn At Your Own Pace</h2>
                                </div> 
						
                            <div class="inner-column" style="margin-top:-40px;">
                                <div class="image titlt" data-tilt data-tilt-max="4">
								
								<div class="embed-responsive embed-responsive-16by9">
  <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/hidzPobYRQo" allowfullscreen></iframe>
</div>
								
								
                                  
                                </div>
                            </div>
							<br>
							 <div class="inner-column">
                                <h5 style="color:#000;">Benefits of Digiool</h5>
                                <div class="text">
                                    <p>Get Unlimited Access to interactive Live Classes on Jharkhand's largest online learning platform - Digiool. Start connecting with Top Educators today.</p>
                                </div>
                            </div>
							
							
							
                        </div> 
                    </div>
                </div>
            </section>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
         
			
			
			
			 <section class="courses-section" style="background-color:#f2f2f2;">
              
             
             
                <div class="auto-container">
                    <div class="sec-title centered">
                        <h2>Learn From Anywhere At Your Own Pace</h2>
                        <div class="text" style="font-size: 16px; font-style: oblique; margin-top: 6px; color: #770052;">Sign up when you want, complete when you're able. Save on time, save on cost. Access wherever. <br> Timetable as you like. Facilities without travel.</div>
                    </div>
                    <div class="row clearfix">
                        <div class="page-links-box">
                            <center>
                                
                                <a href="http://www.digiool.com/digiool/StudentSignUp.jsp" style="color: black !important;" class="link"><span class="icon flaticon-bar-chart"></span>JEE Zeal Batch 2023</a>
                                    
                                <a href="http://www.digiool.com/digiool/StudentSignUp.jsp" style="color: black !important;" class="link"><span class="icon flaticon-bar-chart"></span>JEE Target Batch 2022</a>
                                    
                                <a href="http://www.digiool.com/digiool/StudentSignUp.jsp" style="color: black !important;" class="link"><span class="icon flaticon-bar-chart"></span>NEET Zeal Batch 2023</a>
                                    
                                <a href="http://www.digiool.com/digiool/StudentSignUp.jsp" style="color: black !important;" class="link"><span class="icon flaticon-bar-chart"></span>NEET Target Batch 2022</a>
                                    
                            </center>
                        </div> 
                    </div>
                </div>
            </section> 
			
			
			
		<!-- Contact Page Section -->
    <section class="contact-page-section">
		<div class="pattern-layer-three" style="background-image: url(images/icons/icon-8.png)"></div>
		<div class="auto-container">
			<div class="row clearfix">
				
				<!-- Info Column -->
				<div class="info-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						
						<center><h2> How it works</h2></center>
						 <div class="container">
        <div class="row mb-2">
            <div class="col-md-12">
              <a href="#" class="text-dark">
              <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-xs-1 col-sm-2 col-md-1 mr-3" >
						<div  style="background-color:#690372; height:50px; width:50px; border-radius:50%; padding-top:5px; font-size:22px; font-weight:bold; color:#fff;">
                      <center> <p>1</p></center>
					   </div>
                        </div>
                        <div class="col-xs-8 col-sm-7 col-md-9">
                      
                        <p>After registering, you can select and confirm a time slot for your free class as per your convenience</p>
                        </div>
                    </div>
                </div>
              </div>
              </a>
            </div>
        </div>
       
         <div class="row mb-2">
            <div class="col-md-12">
              <a href="#" class="text-dark">
              <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-xs-1 col-sm-2 col-md-1 mr-3" >
						<div  style="background-color:#030b72; height:50px; width:50px; border-radius:50%; padding-top:5px; font-size:22px; font-weight:bold; color:#fff;">
                      <center> <p>2</p></center>
					   </div>
                        </div>
                        <div class="col-xs-8 col-sm-7 col-md-9">
                      
                        <p>Every class will be for 60 minutes</p>
                        </div>
                    </div>
                </div>
              </div>
              </a>
            </div>
        </div>
      
      
	  
	  
	   <div class="row mb-2">
            <div class="col-md-12">
              <a href="#" class="text-dark">
              <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-xs-1 col-sm-2 col-md-1 mr-3" >
						<div  style="background-color:#647203; height:50px; width:50px; border-radius:50%; padding-top:5px; font-size:22px; font-weight:bold; color:#fff;">
                      <center> <p>3</p></center>
					   </div>
                        </div>
                        <div class="col-xs-8 col-sm-7 col-md-9">
                      
                        <p>Join the class on time and learn from our top teachers</p>
                        </div>
                    </div>
                </div>
              </div>
              </a>
            </div>
        </div>
	  
	  
	  
	   <div class="row mb-2">
            <div class="col-md-12">
              <a href="#" class="text-dark">
              <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-xs-1 col-sm-2 col-md-1 mr-3" >
						<div  style="background-color:#722203; height:50px; width:50px; border-radius:50%; padding-top:5px; font-size:22px; font-weight:bold; color:#fff;">
                      <center> <p>4</p></center>
					   </div>
                        </div>
                        <div class="col-xs-8 col-sm-7 col-md-9">
                      
                        <p>Get all your doubts clarified instantly during the class</p>
                        </div>
                    </div>
                </div>
              </div>
              </a>
            </div>
        </div>
	  
	  
	   <div class="row mb-2">
            <div class="col-md-12">
              <a href="#" class="text-dark">
              <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-xs-1 col-sm-2 col-md-1 mr-3" >
						<div  style="background-color:#723f03; height:50px; width:50px; border-radius:50%; padding-top:5px; font-size:22px; font-weight:bold; color:#fff;">
                      <center> <p>5</p></center>
					   </div>
                        </div>
                        <div class="col-xs-8 col-sm-7 col-md-9">
                      
                        <p>Revise your concepts after class through the homework that will be provided</p>
                        </div>
                    </div>
                </div>
              </div>
              </a>
            </div>
        </div>
	  
	  
       
      
      
    </div>
						
					</div>
				</div>
				
				<!-- Form Column -->
				<div class="form-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="circle-layer"></div>
						<div class="pattern-layer-one" style="background-image: url(images/icons/icon-7.png)"></div>
						<div class="pattern-layer-two" style="background-image: url(images/icons/icon-9.png)"></div>
						<h2>Call Your Counsellor</h2>
						<div class="text">Ask Anything Related to Your Career Here,<br>@+91-9341528591 Drop Your Query. </div>
						
						<!-- Contact Form -->
						<div class="contact-form">
							<form method="post" action="sendemail.php" id="contact-form">
								
								<div class="form-group">
									<input type="text" name="username" placeholder="Name" required="">
								</div>
								
								<div class="form-group">
									<input type="email" name="email" placeholder="Email" required="">
								</div>
								
								<div class="form-group">
									<input type="text" name="phone" placeholder="Phone" required="">
								</div>
								
								<div class="form-group">
									<textarea class="" style="height: 100px;" name="message" placeholder="For Query"></textarea>
								</div>
								
								 <div class="form-group">
                            <div class="g-recaptcha" data-sitekey="6LfKURIUAAAAAO50vlwWZkyK_G2ywqE52NU7YO0S" data-callback="verifyRecaptchaCallback" data-expired-callback="expiredRecaptchaCallback"></div>
                            <input class="form-control d-none" data-recaptcha="true" required data-error="Please complete the Captcha">
                            <div class="help-block with-errors"></div>
                        </div>
								
								
								<div class="form-group">
									<button class="btn btn-primary btn-ultra-voilet" type="submit" name="submit-form">Submit</button>
								</div>
								
							</form>
						</div>
							
					</div>
						
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- End Contact Page Section -->	
			
			
			
			 <script src='https://www.google.com/recaptcha/api.js'></script>
			
			
			
			
			
			
			
			
           


<?php include 'footer.php';?>