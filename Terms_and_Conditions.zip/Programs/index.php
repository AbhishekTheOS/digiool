<!DOCTYPE html>
<html lang="en" class="js">
	

<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content=" a multi purpose landing page">
		<meta name="author" content="bestpixels">
		
		<!-- Fav Icon  -->
		<link rel="icon" href="images/favicon.png" type="image/x-icon">
		
		
		<!-- Site Title  -->
		<title>Digiool | A Digital School</title> 
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100;300;400;500;700;900&amp;display=swap" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<meta content="Digiool | A Digital School" name="author">
<meta name="keywords" content="online courses,learn english online,online learning,learn anything online,best way to learn finnish online,learn finnish online course,online course,learn to drive online course,online,learn to drive online course - everything a learner driver needs!,learn english,how i learn things online,how to learn things online,learn python online,learn python,hunar online courses,learn graphic design online,online courses in fashion designing,english courses online,digiool,Jharkhand Online Video Class,Jharkhand Video Class,TheOS Live Class,digiool.digioll,digi wool,digool,digi ool,online education platforms in india,top online education platforms in world,online learning platforms for business,online learning platforms examples,best free online learning platforms,online learning platforms for schools,online learning platforms free,online learning platforms for kids,online learning platforms examples, online live class platform, best online course platforms 2020, list of online learning platforms, how to create an online course for free, online learning platforms india, hosting courses online, online learning platforms free">
<meta content="Digiool, A Pioneer edtech based in Ranchi, is an online learning platform where Students can learn from KG to PG at their own Pace. Stay Safe, Stay at Home while Learning with World Class Faculties. Digiool brings Education at your Door Place." name="description">

		<!-- Bootstrap core CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.css" >
		
		<!-- Linea CSS -->
		<link rel="stylesheet" href="lib/linea/styles.css"/>
		
		<!-- Magnific Popup CSS -->
		<link rel="stylesheet" href="lib/Magnific-Popup/dist/magnific-popup.css"/>
		
		<!-- Custom styles for this template -->
		<link href="css/font.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		
		
		<!-- Color CSS -->
		<link href="css/color-1.css" rel="stylesheet" id="layoutstyle">
			
		
		<link rel="stylesheet" href="themes_panel.css">
	
		
	</head>
	<body>
		
		<!-- Head Area Start -->
		<div class="head-area">
			<div class="overlay">
				<div class="container">
					<div class="row">
						<div class="col-md-7">
							
							
								<div class="lead-form">
								<div class="lead-form-innr border1px">
									<center><h3 style="">Book your Free Class</h3>
									<h6>Learn from India's best teachers</h6></center>
							<hr>

							<form>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4" style="padding: 10px 0px;">Name Your Child</label>
      <input type="text" class="form-control" id="inputEmail4" placeholder="Name Your Child">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4" style="padding: 10px 0px;">Phone No.</label>
      <input type="text" class="form-control" id="inputPassword4" placeholder="Phone No.">
    </div>
	
	 <div class="form-group col-md-6">
      <label for="inputPassword4" style="padding: 10px 0px;">Email Id</label>
      <input type="email" class="form-control" id="inputPassword4" placeholder="Email Id">
    </div>
	
	
	<div class="form-group col-md-6">
       <label for="inputState" style="padding: 10px 0px;">State</label>
      <select id="inputState" class="form-control">
        <option selected>Choose...</option>
        <option>...</option>
      </select>
    </div>
	
	
	
	<div class="form-group col-md-6">
       <label for="inputState" style="padding: 10px 0px;">Programme</label>
      <select id="inputState" class="form-control">
        <option selected>Choose...</option>
        <option>...</option>
      </select>
    </div>
	
		
	<div class="form-group col-md-6">
       <label for="inputState" style="padding: 10px 0px;">Section</label>
      <select id="inputState" class="form-control">
        <option selected>Choose...</option>
        <option>...</option>
      </select>
    </div>
	
	
	
  </div>
 

<center>
  <button type="submit" class="btn btn-primary" style="margin: 10px 0px;">Schedule A free class</button></center>
</form>
							
							
							
							
								</div>	
							</div>	
							
							
									<!-- Home Page intro End -->
						</div>
						
						<div class="col-md-5">
						<br><br><br>
							<!-- Site Logo Start -->
							<center><div class="logo">
								<a href="#"><img src="images/logo_digiool.png" style="width:180px;" alt="logo" /></a>
							</div>	</center>		<!-- Site Logo End -->
							
							<!-- Home Page intro Start -->
							<div class="intro">
								<h1 style="color:#000;">How it works</h1>
								<h6 style="color:#000;">Learn from India's best teachers</h6>
								<div class="text-center">
									<a class="learn-more"><img src="images/downarrow.png" alt="downarrow" /></a>
								</div>
							</div>	
						
						</div>
					</div>
				</div>
			</div>
		</div>			<!-- Head Area End -->
		
		<!-- Service Area Start -->
		<div class="service-area" id="service">
			<div class="service-area-innr graybg">
				<div class="container">
					<div class="row text-center">
						
						<!-- Single Service Start -->
						<div class="col-md-3 col-sm-6">
							<div class="single-service lift-top">
							
								
								<div class="service-dec">
									<div class="service-dec-innr border1px">
									<center><div  style="background-color:#723f03; height:50px; width:50px; border-radius:50%; padding-top:10px;  font-weight:bold; color:#fff;">
                       <p style="font-size:40px;">1</p>
					   </div></center>
										<p>After registering, you can select and confirm a time slot for your free class as per your convenience</p>
									</div>
								</div>
							</div>
						</div>			<!-- Single Service End -->
						
						<!-- Single Service Start -->
						<div class="col-md-3 col-sm-6">
							<div class="single-service lift-top">
								
							
								<div class="service-dec">
									<div class="service-dec-innr border1px">
									
									<center><div  style="background-color:#723f03; height:50px; width:50px; border-radius:50%; padding-top:10px;  font-weight:bold; color:#fff;">
                       <p style="font-size:40px;">2</p>
					   </div></center>
									
										<p>Every class will be <br>for 60 minutes</p>
									</div>
								</div>
							</div>
						</div>			<!-- Single Service End -->
						
						<!-- Single Service Start -->
						<div class="col-md-3 col-sm-6">
							<div class="single-service lift-top">
								
							
								<div class="service-dec">
									<div class="service-dec-innr border1px">
									
									<center><div  style="background-color:#723f03; height:50px; width:50px; border-radius:50%; padding-top:10px;  font-weight:bold; color:#fff;">
                       <p style="font-size:40px;">3</p>
					   </div></center>
									
										<p>Join the class on time and learn from our top teachers</p>
									</div>
								</div>
							</div>
						</div>			<!-- Single Service End -->
						
						<!-- Single Service Start -->
						<div class="col-md-3 col-sm-6">
							<div class="single-service lift-top">
								
								
								<div class="service-dec">
									<div class="service-dec-innr border1px">
									<center><div  style="background-color:#723f03; height:50px; width:50px; border-radius:50%; padding-top:10px;  font-weight:bold; color:#fff;">
                       <p style="font-size:40px;">4</p>
					   </div></center>
									
										<p>Get all your doubts clarified instantly during the class</p>
									</div>
								</div>
							</div>
						</div>			<!-- Single Service End -->
					</div>
				</div>
			</div>
		</div>				<!-- Service Area End -->
		
	
	
	
		
	<div id="footers" style=" position: fixed; left: 0px; bottom: 0px; width: 100%; background: #000000d9; z-index: 1; text-align: right;">
    © <a href="http://digiool.com/" target="_blank" style="color:white;"> Digiool Education Private Limited</a>  
</div>
	
	
	
		
		
		
		<!-- Bootstrap core JavaScript
		================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->
		
		<script src="js/jquery.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		<!-- jQuery Magnific-Popup
		================================================== -->
		<script src="lib/Magnific-Popup/dist/jquery.magnific-popup.min.js"></script>
		
		<script src="lib/Simple-Form/validation.js"></script>
		<script src="lib/Simple-Form/form.js"></script>
		<script src="lib/Simple-Form/index.js"></script>
		
		<!-- jQuery mb.YTPlayer
		================================================== -->
		<script src="lib/jquery.mb.YTPlayer/inc/jquery.mb.YTPlayer.js"></script>
		
		<!-- jQuery Custom
		================================================== -->
		<script src="js/custom.js" type="text/javascript"></script>
		
		
		

<script src="themes_panel.js"></script>	
	</body>


</html>
