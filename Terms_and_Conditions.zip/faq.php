<?php include 'header_menu.php';?>

          
		  
		  
	<!-- Page Title Section -->
    <section class="page-title-section">
		<div class="icon-layer-one" style="background-image: url(images/icons/icon-5.png)"></div>
		<div class="icon-layer-two" style="background-image: url(images/icons/icon-6.png)"></div>
		<div class="icon-layer-three" style="background-image: url(images/icons/icon-4.png)"></div>
		<div class="icon-layer-four" style="background-image: url(images/icons/icon-7.png)"></div>
		<div class="icon-layer-five" style="background-image: url(images/icons/icon-7.png)"></div>
		<div class="icon-layer-six" style="background-image: url(images/icons/icon-8.png)"></div>
		<div class="auto-container">
			<!-- Page Breadcrumb -->
			<ul class="page-breadcrumb">
				<li><a href="index.php">Home</a></li>
				<li>faq</li>
			</ul>
            <div class="content-box">
				<h2>Frequently asked questions</h2>
				
			</div>
		</div>
	</section>
	<!-- End Page Title Section -->
	
	<!-- Faq Blocks Section -->
	<section class="faq-blocks-section">
		<div class="auto-container">
			<div class="inner-container">
				<div class="row clearfix">
					
					<!-- Faq Block -->
					<div class="faq-block col-lg-4 col-md-6 col-sm-12">
						<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
							<div class="icon-box">
								<span class="icon flaticon-unity"></span>
							</div>
							<h5><a href="#">Become a Partner</a></h5>
							<div class="text">A Partnership Agreement is established when 2 or more people who get into business together formalise the terms of a Partnership business.</div>
							<a href="about.php" class="read-more">Read More</a>
						</div>
					</div>
					
					<!-- Faq Block -->
					<div class="faq-block col-lg-4 col-md-6 col-sm-12">
						<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
							<div class="icon-box">
								<span class="icon flaticon-calendar"></span>
							</div>
							<h5><a href="#">Become a Careers </a></h5>
							<div class="text">This is the official page where you can share all your queries, feedback, complaints or any concerns you may have about Digiool learning programs.</div>
							<a href="#" class="read-more">Read More</a>
						</div>
					</div>
					
					<!-- Faq Block -->
					<div class="faq-block col-lg-4 col-md-6 col-sm-12">
						<div class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
							<div class="icon-box">
								<span class="icon flaticon-customer"></span>
							</div>
							<h5><a href="#">Join Our Team</a></h5>
							<div class="text">At Digiool we persevere to live up to our reputation as the world's most valuable and loved Ed-tech company. We believe in revolutionizing education</div>
							<a href="teacher.php" class="read-more">Read More</a>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</section>
	<!-- End Faq Blocks Section -->
	
	<!-- Faq Section -->
	<section class="faq-section">
		<div class="auto-container">
			<div class="row clearfix">
				
				<!-- Column -->
				<div class="column col-lg-6 col-md-12 col-sm-12">
					<div class="title-box">
						<h4>Primary FAQ</h4>
					</div>
					
					<ul class="accordion-box">
						
						<!-- Block -->
						<li class="accordion block">
							<div class="acc-btn">Are Digiool programs applicable for all classes? <div class="icon fa fa-angle-down"></div></div>
							<div class="acc-content">
								<div class="content">
									<div class="text">
										<p>Digiool learning programs are for students from LKG to Class 12. We also offer programs for competitive exams like JEE, NEET, and IAS</p>
									</div>
								</div>
							</div>
						</li>
						
						<!--Block-->
						<li class="accordion block active-block">
							<div class="acc-btn active">How do I get started?<div class="icon fa fa-angle-down"></div></div>
							<div class="acc-content current">
								<div class="content">
									<div class="text">
										<p>Download the app or connect with our team at +91-9341528591 for a free demo session.</p>
									</div>
								</div>
							</div>
						</li>
						
						<!--Block-->
						<li class="accordion block">
							<div class="acc-btn">Do all programs have live-doubt solving?<div class="icon fa fa-angle-down"></div></div>
							<div class="acc-content">
								<div class="content">
									<div class="text">
										<p>Live doubt-solving feature is available as a part of Digiool Classes offering.</p>
									</div>
								</div>
							</div>
						</li>

						<!--Block-->
						<li class="accordion block">
							<div class="acc-btn">What is a free demo class and how do I register for it? <div class="icon fa fa-angle-down"></div></div>
							<div class="acc-content">
								<div class="content">
									<div class="text">
										<p>Your child can attend a free demo class by our top teachers to experience our programmes first-hand. This is a great way to understand Digiool way of teaching. Our counselor will help book a demo class for you at your convenience.</p>
									</div>
								</div>
							</div>
						</li>
						
						<!-- Block -->
						<li class="accordion block">
							<div class="acc-btn">Are the demo classes free?<div class="icon fa fa-angle-down"></div></div>
							<div class="acc-content">
								<div class="content">
									<div class="text">
										<p>Yes, they are free. More details about the demo classes will be provided by our counselor.</p>
									</div>
								</div>
							</div>
						</li>
						
						<!-- Block -->
						<li class="accordion block">
							<div class="acc-btn">Are Digiool programs mapped to the school syllabus/curriculum?<div class="icon fa fa-angle-down"></div></div>
							<div class="acc-content">
								<div class="content">
									<div class="text">
										<p>Yes, the programs are personalised for students as per the school syllabus.Yes, the programs are personalised for students as per the school syllabus.</p>
									</div>
								</div>
							</div>
						</li>
						
					</ul>
					
				</div>
				<!-- Column -->
				<div class="column col-lg-6 col-md-12 col-sm-12">
					<div class="title-box">
						<h4>Other questions</h4>
					</div>
					
					<ul class="accordion-box">
						
						<!-- Block -->
						<li class="accordion block">
							<div class="acc-btn">How is Digiool Classes different from Digiool The Learning App?<div class="icon fa fa-angle-down"></div></div>
							<div class="acc-content">
								<div class="content">
									<div class="text">
										<p>Digiool Classes is a comprehensive online tutoring program. It brings together online classes by India&#8217;s top teachers along with instant doubt resolution. Your child can revise through extra classes with Digiool assigned teachers and access lessons on the Digiool app too. Additionally, Digiool Classes offer monthly tests along with comprehensive monthly progress reports.</p>
									</div>
								</div>
							</div>
						</li>
						
						<!--Block-->
						<li class="accordion block active-block">
							<div class="acc-btn active">What is the difference between Digiool Teacher and Digiool Mentor?<div class="icon fa fa-angle-down"></div></div>
							<div class="acc-content current">
								<div class="content">
									<div class="text">
										<p>Digiool provides India’s best teachers and subject matter experts to teach and clear doubts of the students in an ongoing class. Whereas, the mentor is a dedicated person assigned to every student who helps them strengthen their foundations, align their learning to long-term goals and become self-initiated learners. Also, PTA meetings are regularly conducted by the mentors to discuss the students’ progress.</p>
									</div>
								</div>
							</div>
						</li>
						
						<!--Block-->
						<li class="accordion block">
							<div class="acc-btn">Where can I track my child&#8217;s progress? <div class="icon fa fa-angle-down"></div></div>
							<div class="acc-content">
								<div class="content">
									<div class="text">
										<p>A child’s progress can be accessed through the Parent Zone section in the app. A progress report is available for every child and can be accessed by switching the profile.</p>
									</div>
								</div>
							</div>
						</li>

						<!--Block-->
						<li class="accordion block">
							<div class="acc-btn">What age group is Disney. Digiool Early Learn for? <div class="icon fa fa-angle-down"></div></div>
							<div class="acc-content">
								<div class="content">
									<div class="text">
										<p>The Digiool Learning App featuring Disney is a learning program for 4–8-year-olds in LKG to classes 1-3.</div>
</div></p>
									</div>
								</div>
							</div>
						</li>
						
						
						
						
						
					</ul>
					
				</div>
				
			</div>
		</div>
	</section>
	<!-- End Faq Section -->
		  

















<?php include 'footer.php';?>