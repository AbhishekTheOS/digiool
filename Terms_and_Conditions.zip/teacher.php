<?php include 'header_menu.php';?>

          


  <!-- Page Title Section -->
            <section class="page-title-section">
                <div class="icon-layer-one" style="background-image: url('images/icons/icon-5.png')"></div>
                <div class="icon-layer-two" style="background-image: url('images/icons/icon-6.png')"></div>
                <div class="icon-layer-three" style="background-image: url('images/icons/icon-4.png')"></div>
                <div class="icon-layer-four" style="background-image: url('images/icons/icon-7.png')"></div>
                <div class="icon-layer-five" style="background-image: url('images/icons/icon-7.png')"></div>
                <div class="icon-layer-six" style="background-image: url('images/icons/icon-8.png')"></div>
                <div class="auto-container"> 

                    <ul class="page-breadcrumb">
                        <li><a href="index.html">Home</a></li>
                        <li>Our Leadership Team</li>
                    </ul>
                    <div class="content-box">
                        <h2>Our Leadership Team</h2>
						<br>
<p style="font-size:18px;">With over 50 years of combined experience, we have got a well-seasoned team at the helm.</p>
                    </div>
                </div>
            </section>
            <!-- End Page Title Section -->















         <!-- Team Section Two -->
            <section class="team-section-two">
                <div class="auto-container">
                    <div class="pattern-layer" style="background-image:url(images/background/pattern-18.png)"></div>
                    <div class="pattern-layer-two" style="background-image:url(images/background/pattern-19.png)"></div>
                    <div class="pattern-layer-three" style="background-image:url(images/icons/icon-4.png)"></div>
                    <div class="pattern-layer-four" style="background-image:url(images/icons/icon-4.png)"></div>
                    <div class="inner-container">
                        <div class="pattern-layer-five" style="background-image:url(images/icons/icon-2.png)"></div>
                        <div class="color-layer"></div>
                        <div class="row clearfix">

                            <!-- Team Block -->
                            <div class="team-block col-lg-3 col-md-6 col-sm-12">
                                <div class="inner-box">
                                    <div class="image">
                                        <a href="#"><img src="images/teacher/1.jpg" alt="" /></a>
                                    </div>
                                    <div class="lower-content">
                                        <h5><a href="#">Mr. Rakesh Kumar</a></h5>
                                        <div class="designation">Physics Teacher</div>
										 <div class="designation">10 Years + Exp.</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Team Block -->
                            <div class="team-block col-lg-3 col-md-6 col-sm-12">
                                <div class="inner-box">
                                    <div class="image">
                                        <a href="#"><img src="images/teacher/2.jpg" alt="" /></a>
                                    </div>
                                    <div class="lower-content">
                                        <h5><a href="#">Mr. R. K. Singh</a></h5>
                                        <div class="designation"> Biology Teacher</div>
										<div class="designation"> 6 Years + Exp</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Team Block -->
                            <div class="team-block col-lg-3 col-md-6 col-sm-12">
                                <div class="inner-box">
                                    <div class="image">
                                        <a href="#"><img src="images/teacher/3.jpg" alt="" /></a>
                                    </div>
                                    <div class="lower-content">
                                        <h5><a href="#">Mr. Vishal Gupta</a></h5>
                                        <div class="designation">Physics Teacher</div>
										<div class="designation">BIT Sindri, 6 Years + Exp.</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Team Block -->
                            <div class="team-block col-lg-3 col-md-6 col-sm-12">
                                <div class="inner-box">
                                    <div class="image">
                                        <a href="#"><img src="images/teacher/4.jpg" alt="" /></a>
                                    </div>
                                    <div class="lower-content">
                                        <h5><a href="#">Mr. Hemant Sinha</a></h5>
                                        <div class="designation">Chemistry Teacher</div>
										<div class="designation">6 Years + Exp.</div>
                                    </div>
                                </div>
                            </div>



                        </div>
                    </div>
                </div>
            </section>
            <!-- End Team Section -->











		  





<?php include 'footer.php';?>